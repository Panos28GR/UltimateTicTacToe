// // Copyright 2016 theaigames.com (developers@theaigames.com)
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//        http://www.apache.org/licenses/LICENSE-2.0
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
//  
//    For the full copyright and license information, please view the LICENSE
//    file that was distributed with this source code.
package bot;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Field class
 *
 * Handles everything that has to do with the field, such as storing the current
 * state and performing calculations on the field.
 *
 * @author Jim van Eeden <jim@starapple.nl>, Joost de Meij <joost@starapple.nl>
 */
public class Field {

    private int mRoundNr;
    private int mMoveNr;
    private int[][] mBoard;
    private int[][] mMacroboard;

    private final int COLS = 9, ROWS = 9;
    private String mLastError = "";

    public static int[] winningPatterns = {
        0b111000000, 0b000111000, 0b000000111, // patterns nikwn gia tis grammes
        0b100100100, 0b010010010, 0b001001001, // patterns nikwn gia tis stiles
        0b100010001, 0b001010100 // diagonia patterns nikwn
    };

    public static HashMap<Integer, Integer[]> positionPatterns;		// antistoixish metaksi tis thesis enos bit kai tis sintetagmenes tou antistixou keliou se pinaka 

    // mapping
    static {
        positionPatterns = new HashMap<>();
        // gia kathe ena keli tou ypopinaka
        positionPatterns.put(0, new Integer[]{0, 0});
        positionPatterns.put(1, new Integer[]{0, 1});
        positionPatterns.put(2, new Integer[]{0, 2});
        positionPatterns.put(3, new Integer[]{1, 0});
        positionPatterns.put(4, new Integer[]{1, 1});
        positionPatterns.put(5, new Integer[]{1, 2});
        positionPatterns.put(6, new Integer[]{2, 0});
        positionPatterns.put(7, new Integer[]{2, 1});
        positionPatterns.put(8, new Integer[]{2, 2});
    }

    final static long TABLE_WIN_SCORE = 1000000;	// MACROBOARD SCORE
    final static int SUB_TABLE_WIN_SCORE = 1000;	// MICROBOARD SCORE

    public Field() {
        mBoard = new int[COLS][ROWS];	// olokliros o pinakas tou paixnidiou
        mMacroboard = new int[COLS / 3][ROWS / 3];	// ypopinakas tou paixnidiou
        clearBoard();
    }

    /**
     * Parse data about the game given by the engine
     *
     * @param key : type of data given
     * @param value : value
     */
    public void parseGameData(String key, String value) {
        if (key.equals("round")) {
            mRoundNr = Integer.parseInt(value);
        } else if (key.equals("move")) {
            mMoveNr = Integer.parseInt(value);
        } else if (key.equals("field")) {
            parseFromString(value); /* Parse Field with data */

        } else if (key.equals("macroboard")) {
            parseMacroboardFromString(value); /* Parse macroboard with data */

        }
    }

    /**
     * Initialise field from comma separated String
     *
     * @param String :
     */
    public void parseFromString(String s) {
        System.err.println("Move " + mMoveNr);
        s = s.replace(";", ",");
        String[] r = s.split(",");
        int counter = 0;
        for (int y = 0; y < ROWS; y++) {
            for (int x = 0; x < COLS; x++) {
                mBoard[x][y] = Integer.parseInt(r[counter]);
                counter++;
            }
        }
    }

    /**
     * Initialise macroboard from comma separated String
     *
     * @param String :
     */
    public void parseMacroboardFromString(String s) {
        String[] r = s.split(",");
        int counter = 0;
        for (int y = 0; y < 3; y++) {
            for (int x = 0; x < 3; x++) {
                mMacroboard[x][y] = Integer.parseInt(r[counter]);
                counter++;
            }
        }
    }

    public void clearBoard() {
        for (int x = 0; x < COLS; x++) {
            for (int y = 0; y < ROWS; y++) {
                mBoard[x][y] = 0;
            }
        }
    }

    public ArrayList<Move> getAvailableMoves() {
        ArrayList<Move> moves = new ArrayList<Move>();

        for (int y = 0; y < ROWS; y++) {
            for (int x = 0; x < COLS; x++) {
                if (isInActiveMicroboard(x, y) && mBoard[x][y] == 0) {
                    moves.add(new Move(x, y));
                }
            }
        }

        return moves;
    }

    public Boolean isInActiveMicroboard(int x, int y) {
        return mMacroboard[(int) x / 3][(int) y / 3] == -1;
    }

    /**
     * Returns reason why addMove returns false
     *
     * @param args :
     * @return : reason why addMove returns false
     */
    public String getLastError() {
        return mLastError;
    }

    @Override
    /**
     * Creates comma separated String with player ids for the microboards.
     *
     * @param args :
     * @return : String with player names for every cell, or 'empty' when cell
     * is empty.
     */
    public String toString() {
        String r = "";
        int counter = 0;
        for (int y = 0; y < ROWS; y++) {
            for (int x = 0; x < COLS; x++) {
                if (counter > 0) {
                    r += ",";
                }
                r += mBoard[x][y];
                counter++;
            }
        }
        return r;
    }

    /**
     * Checks whether the field is full
     *
     * @param args :
     * @return : Returns true when field is full, otherwise returns false.
     */
    public boolean isFull() {
        for (int x = 0; x < COLS; x++) {
            for (int y = 0; y < ROWS; y++) {
                if (mBoard[x][y] == 0) {
                    return false; // At least one cell is not filled
                }		// All cells are filled
            }
        }
        return true;
    }

    // H parakatw methodos prosomoiwnei thn kinhsh tou paixth sto trexon pedio
    public boolean simulateMove(Move move, int player) {
        // Prosomoiwsh sintetagmenwn
        int x = move.mX;
        int y = move.mY;
        int thisX = x / 3;
        int thisY = y / 3;
        int sentX = x % 3;
        int sentY = y % 3;

        // Topothetisi tou paixth ston pinaka(mBoard)
        mBoard[x][y] = player;

        // Prosomoiwsh tou trexontos ypopinaka(mMacroboard)
        int[][] thisSubTable = getSubTableFromTable(thisX, thisY, mBoard);

        // Ananewsh tou ypopinaka
        if (isPlayerWinner(thisSubTable, player)) {
            mMacroboard[thisX][thisY] = player;
        } else {
            mMacroboard[thisX][thisY] = 0;
        }

        int[][] sentSubTable = getSubTableFromTable(sentX, sentY, mBoard);

        if (!subTableIsTie(sentSubTable) && mMacroboard[sentX][sentY] <= 0) {
            mMacroboard[sentX][sentY] = -1;		// Tou dinoume mia asimanth timh

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (i == sentX && j == sentY) {
                        continue;
                    }
                    if (!subTableIsTie(getSubTableFromTable(i, j, mBoard)) && mMacroboard[i][j] <= 0) {
                        mMacroboard[i][j] = 0;
                    }
                }
            }
        } else {
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    int[][] auxSubTable = getSubTableFromTable(i, j, mBoard);

                    if (mMacroboard[i][j] == 0 && !subTableIsTie(auxSubTable)) {
                        mMacroboard[i][j] = -1;
                    }
                }
            }
        }

        return true;
    }

    // H parakatw methodos aksiologei thn epidosh twn simetexontwn sto pedio
    public long evaluate(int player) {
        int enemy;

        if (player == 0) {
            enemy = 1;
        } else {
            enemy = 0;
        }

        // An iparxei nikhths sthn trexousa katastash epestrepse to score tou
        if (isPlayerWinner(mMacroboard, player)) {
            return TABLE_WIN_SCORE;
        } else if (isPlayerWinner(mMacroboard, enemy)) {
            return 0;
        }

        // antistoixish 1 pros 1 twn ypopinakwn me ta scores
        long[][] scores = new long[3][3]; 	// oso kai oi diastaseis tou pediou(osoi oi ypopinakes)

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                if (mMacroboard[row][col] == player) {
                    scores[row][col] = SUB_TABLE_WIN_SCORE; 	// An to bot mas exei kerdisei ton ypopinaka to score isoutai me to prokathorismeno score gia tous ypopinakes
                } else if (mMacroboard[row][col] == enemy) {
                    scores[col][row] = 0; 	// stin periptwsh pou kerdise o antipalos
                } else {
                    int[][] sub_table = getSubTableFromTable(col, row, mBoard);
                    scores[col][row] = evaluateSubTable(player, sub_table); 	// Kane aksiologhsh
                }

            }
        }

        return evaluateTable(scores);
    }

    // H methodos afth aksiologei ton megalo pinaka(mBoard)
    public static long evaluateTable(long[][] scores) {
        long score = 0; 	// arxikopoihsh tou score
        // arxikopoihsh diagwniwn score pinaka
        long diagonalScoreA = 1;
        long diagonalScoreB = 1;

        // Aksiologhsh grammwn kai sthlwn
        for (int i = 0; i < 3; i++) {
            long rowScore = 1;
            long colScore = 1;

            for (int j = 0; j < 3; j++) {
				// To scores array exei hdh gemistei me ta scores twn ypopinakwn
                // kathe grammh kai kathe sthlh tou pinaka (mBoard) antistoixei se enan ypopinaka(mMacroBoard)
                // ara kai ta scores twn grammwn kai sthlwn tou pinaka isoutai me ta scores twn ypopinakwn
                rowScore = rowScore + scores[i][j];
                colScore = colScore + scores[j][i];		// antistrofa edw efoson einai sthles
            }

            score = score + rowScore + colScore; 	// prosthetoume ta scores kathe grammhs kai kathe sthlhs sto geniko score
        }

        // Aksiologhsh diagwniwn
        for (int i = 0; i < 3; i++) {
            // Paromoia logikh me ta scores kai edw
            diagonalScoreA = diagonalScoreA * scores[i][i];
            diagonalScoreB = diagonalScoreB * scores[2 - i][i];
        }

        score = score + diagonalScoreA + diagonalScoreB;	// prosthetoume ta scores kathe diagwniou sto geniko score

        return score; // Epistrofh tou telikou score
    }

    // Aksiologhsh ypopinakwn(mMacroboard)
    public static int evaluateSubTable(int player, int[][] sub_table) {
        int enemy;

        if (player == 0) {
            enemy = 1;
        } else {
            enemy = 0;
        }

        // Oi 2 Integers antistoixoun se id paixth kai se score
        HashMap<Integer, Integer> assignScore = new HashMap<>();

        assignScore.put(0, 1);		// den oloklirothike o ypopinakas logw termatismou
        assignScore.put(player, 10);	// to score tou bot mas(player) 
        assignScore.put(enemy, 0);		// to score tou antipalou

        int score = 0; 	// arxikopoihsh tou genikou score tou ypopinaka
        // arxikopoihsh diagwniwn score ypopinaka
        int diagonalScoreA = 1;
        int diagonalScoreB = 1;

        // aksiologhsh grammwn kai sthlwn
        for (int i = 0; i < 3; i++) {
            int rowScore = 1; 	// arxikopoihsh score grammwn
            int colScore = 1;	// arxikopoihsh score sthlwn

            for (int j = 0; j < 3; j++) {
                // fernoume ta scores apo to HashMap kai ta antistoixoume se kathe grammh 'h sthlh
                rowScore = rowScore * assignScore.get(sub_table[i][j]);
                colScore = colScore * assignScore.get(sub_table[j][i]);	// antistrofa edw efoson einai sthles
            }

            score = score + rowScore + colScore; // prosthetoume ta scores kathe grammhs kai kathe sthlhs sto geniko score
        }

        // aksiologhsh diagwniwn
        for (int i = 0; i < 3; i++) {
            diagonalScoreA = assignScore.get(sub_table[i][i]);
            diagonalScoreB = assignScore.get(sub_table[2 - i][i]);
        }

        score = score + diagonalScoreA + diagonalScoreB; 	// prosthetoume ta scores kathe diagwniou sto geniko score

        return score;	// epistrofh tou telikou score tou ypopinaka
    }

    // H parakatw methodos pairnei mia kinhsh tou paixth sto arxiko pedio kai thn anairei thetwntas thn timh pou eixe to arxiko pedio arxika
    public void undo(Move move, Field originalField) {
        int x = move.mX;
        int y = move.mY;
        mBoard[x][y] = 0;

        for (int i = 0; i < COLS / 3; i++) {
            System.arraycopy(originalField.mMacroboard[i], 0, this.mMacroboard[i], 0, ROWS / 3);	// Antigrafh ths prohgoumenhs katastashs
            // Apo to shmeio 0 tou ypopinaka tou arxikou pediou sto shmeio 0 tou trexontos ypopinaka
        }
    }

    public static boolean subTableIsTie(int[][] sub_table) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                if (sub_table[row][col] == 0) {
                    return false;
                }
            }
        }

        return true;
    }

    // Ftiaxnei ena 9-bit pattern ypopinaka gia ton paixth
    static int createPattern(int[][] square, int player) {
        int pattern = 0b000000000;	// 9-bit pattern gia ta 9 tetragwna
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (square[i][j] == player) {
                    pattern |= (1 << (i * 3 + j));	// bitwise praksh: pattern = pattern OR thn trexousa thesi
                }
            }
        }

        return pattern;
    }

    public int getNrColumns() {
        return COLS;
    }

    public int getNrRows() {
        return ROWS;
    }

    public boolean isEmpty() {
        for (int x = 0; x < COLS; x++) {
            for (int y = 0; y < ROWS; y++) {
                if (mBoard[x][y] > 0) {
                    return false;
                }
            }
        }
        return true;
    }

    // An kapoio pattern nikhs antistoixei se enan ypopinaka, o paixths kerdizei afton ton ypopinaka
    public static boolean isPlayerWinner(int[][] sub_table, int player) {
        int pattern = 0b000000000;	// 9-bit pattern gia ta 9 tetragwna
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                if (sub_table[row][col] == player) {
                    pattern |= (1 << (row * 3 + col));	// bitwise praksh: pattern = pattern OR thn trexousa thesi
                }
            }
        }

        for (int winningPattern : winningPatterns) {
            if ((pattern & winningPattern) == winningPattern) {	// An to trexon pattern antistoixei se kapoio winning pattern to exei kerdisei o paixths
                return true;
            }
        }
        return false;
    }

    public boolean multipleSubTablesActive() {
        int counter = 0;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (mMacroboard[i][j] == -1) {
                    counter++;
                }
                if (counter >= 2) {
                    return true;
                }
            }
        }
        return false;
    }

    // H parakatw methodos kaleitai stis telikes katastaseis kai prospathei na kerdisei olokliro to paixnidi
    public Move victoryTrial(ArrayList<Move> moves, int player) {
        int pattern = createPattern(mMacroboard, player);	// grammh 168 gia tin leitourgia tou createPattern

        Integer[] subTablePosition;

        for (Integer winningPattern : winningPatterns) {		// grammh 42 gia winningPatterns
            if ((subTablePosition = getPosition(pattern, winningPattern)) != null) {
                int[][] auxSubTable = getSubTableFromTable(subTablePosition[0], subTablePosition[1], mBoard);	// grammh 254 gia leitourgia getSubTableFromTable
                int auxPattern = createPattern(auxSubTable, player);

                Integer[] movePosition;
                for (Integer _winningPattern : winningPatterns) {
                    if ((movePosition = getPosition(auxPattern, _winningPattern)) != null) {
                        int x = 3 * subTablePosition[0] * movePosition[0];
                        int y = 3 * subTablePosition[1] * movePosition[1];

                        Move m = new Move(x, y);
                        if (moves.contains(m)) {
                            return m;
                        }
                    }
                }
            }
        }
        return null;
    }

    static Integer[] getPosition(int p, int wp) {	//p = pattern, wp = winningPattern
        int counter = countDiffs(p, wp);

        if (counter == 2) {
            for (int i = 0; i < 9; i++) {
                int patternBit = (p >> i) & 1;
                int winningPatternBit = (wp >> i) & 1;
                if ((winningPatternBit & 1) == 1 && (patternBit & 1) == 0) {
                    return positionPatterns.get(i);
                }
            }
            return null;
        }
        return null;
    }

    // Epistrefei kapoia timh oloklhrwshs paixnidiou eite an exei kerdisei kapoios simetexontas eite an exoun gemisei ola ta kelia
    public boolean isDone() {
        if (isPlayerWinner(mMacroboard, BotParser.mBotId)) {
            return true;
        }

        if (isPlayerWinner(mMacroboard, BotParser.mServerId)) {
            return true;
        }

        return isFull();
    }

    // H parakatw methodos klwnopoiei to arxiko pedio(xrhsh sto BotStarter)
    public Field clone(Field originalField) {
        Field clone = new Field();

        // Klwnopoihsh pinaka
        for (int i = 0; i < COLS; i++) {
            // Xrhsh tis methodou arraycopy tou System gia antigrafh pinakwn
            System.arraycopy(originalField.mBoard[i], 0, clone.mBoard[i], 0, ROWS);
        }

        // Klwnopoihsh ypopinakwn
        for (int i = 0; i < COLS / 3; i++) {
            System.arraycopy(originalField.mMacroboard[i], 0, clone.mMacroboard[i], 0, ROWS / 3);
            // Apo to shmeio 0 tou ypopinaka tou arxikou pediou sto shmeio 0 tou klwnopoihmenou ypopinaka
        }

        // Klwnopoioume epishs kai ton arithmo twn gyrwn kai twn kinhsewn apo to arxiko pedio
        clone.mRoundNr = originalField.mRoundNr;
        clone.mMoveNr = originalField.mMoveNr;

        return clone;	// Epistrofh tou klwnopoihmenou pediou
    }

    // H parakatw methodos ypologizei th diafora metaksi 2 bytes ektelwntas kapoies logikes prakseis
    private static int countDiffs(int byteA, int byteB) {
        int difference = 0;

        for (int i = 0; i < 9; i++) {
            difference += ((byteA >> i) & 1) & ((byteB >> i) & 1);
        }

        return difference;
    }

    // H parakatw methodos vriskei enan ypopinaka(mMacroboard) se mia sigkekrimeni thesi tou pinaka(mBoard)
    public static int[][] getSubTableFromTable(int x, int y, int[][] table) {
        int[][] sub_table = new int[3][3];
        int a, b;
        a = 0;

        for (int i = x * 3; i < (x * 3 + 3); i++) {
            b = 0;

            for (int j = y * 3; j < (y * 3 + 3); j++) {
                sub_table[a][b] = table[i][j];
                b++;
            }
            a++;
        }
        return sub_table;
    }

    /**
     * Returns the player id on given column and row
     *
     * @param args : int column, int row
     * @return : int
     */
    public int getPlayerId(int column, int row) {
        return mBoard[column][row];
    }

    // Getter gia epistrofh tou arithmou ths kinhshs
    public int getMoveNumber() {
        return this.mMoveNr;
    }

    // Getter gia epistrofh tou arithmou tou gyrou
    public int getRoundNumber() {
        return this.mRoundNr;
    }
}
