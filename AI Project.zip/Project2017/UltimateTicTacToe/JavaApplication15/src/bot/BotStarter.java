// // Copyright 2016 theaigames.com (developers@theaigames.com)

//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at

//        http://www.apache.org/licenses/LICENSE-2.0

//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
//
//    For the full copyright and license information, please view the LICENSE
//    file that was distributed with this source code.

package bot;

import java.util.ArrayList;
import java.util.Random;


/**
 * BotStarter class
 * 
 * Magic happens here. You should edit this file, or more specifically
 * the makeTurn() method to make your bot do more than random moves.
 * 
 * @author Jim van Eeden <jim@starapple.nl>
 */

public class BotStarter {
      /**
     * Makes a turn. Edit this method to make your bot smarter.
     * Currently does only random moves.
     *
     * @return The column where the turn was made.
     */

	public Move makeTurn(Field field) {
		//Random r = new Random();
		ArrayList<Move> moves = field.getAvailableMoves();
		//Move move = moves.get(r.nextInt(moves.size())); /* get random move from available moves */
		
		Move next = null;

		if(field.getMoveNumber() == 1){
			return new Move(4, 4);	// H prwth kinhsh prepei na ginei sto kentro tou kentrikou ipopinaka
		}

		// To bot mas tha kinithei se ena adeio tetragwno an xreiastei, wste kai o antipalos na kinithei sto idio tetragwno
		if(isSubTableEmpty(moves)){
			Move m = moves.get(0);
			return new Move(4 * (m.getX() / 3), 4 * (m.getY() / 3));
		}

		if(field.multipleSubTablesActive()){
			if((next = field.victoryTrial(moves, BotParser.mBotId)) != null){
				return next;
			}
		}

		// Evresh kaliterhs kinhshs xrhsimopoiwntas ton algorithmo minmax
		long score = Integer.MIN_VALUE;
		long alpha = Integer.MIN_VALUE;
		long beta = Integer.MAX_VALUE;

		// Ypologismos tou vathous tou dentrou kinhsewn dynamika me vash ton arithmo twn diathesimen kinhsewn
		int depth = getDepth(moves.size(), field);

		// Klwnopoioume to pedio gia na mporoume na prosomoiwsoume tis kinhseis
        Field cloneField = new Field();
		cloneField.clone(field);

		// Prosomoiwnoume kathe mia diathesimh kinhsh
		for(Move m : moves){
			cloneField.simulateMove(m, BotParser.mBotId);

			// Ypologismos tou score ths kinhshs
			long currentScore = minmax(cloneField, depth, alpha, beta, BotParser.mServerId);

			cloneField.undo(m, field);	// Anairesh ths kinhshs tou bot

			// Enhmerwsh tou genikou score kai ektelesh kinhshs
			if(currentScore > score){
				score = currentScore;
				next = m;
			}

		}

		return next;	// Epistrofh ths kinhshs
	}

	public static long minmax(Field field, int depth, long alpha, long beta, int player){
		if(depth == 0 || field.isDone()){
			return field.evaluate(BotParser.mBotId) - field.evaluate(BotParser.mServerId);
		}

		long score = 0;

		ArrayList<Move> moves = field.getAvailableMoves();
		int moveSize = moves.size();

		// Ypologismos vathous dentrou kinhsewn
		if(moveSize > 7){
			int newDepth;

			if(moveSize <= 10){
				newDepth = 5;
			}else if(moveSize > 10 && moveSize <= 17){
				newDepth = 4;
			}else if(moveSize > 17 && moveSize <= 46){
				newDepth = 3;
			}else{
				newDepth = 2;
			}

			depth = Math.min(depth, newDepth);
		}

		// Klwnopoihsh trexontos pediou
		Field clone = field.clone(field);

		// Paizei to bot mas
		if(player == BotParser.mBotId){
			score = Integer.MIN_VALUE;		

			for(Move m : moves){
				clone.simulateMove(m, BotParser.mBotId);	// Klwnopoihsh kathe kinhshs
				// Ypologismos tou score ths kathe kinhshs kalwntas anadromika ton minmax
				long currentScore = minmax(clone, depth - 1, alpha, beta, BotParser.mServerId);
				clone.undo(m, field);	// Anairesh ths kinhshs
				if(currentScore > score){
					// Enhmerwsh tou score
					score = currentScore;
					alpha = score;

					// Xrhsh ab kladematos
					if(alpha >= beta){
						return score;
					}
				}
			}
		// Paizei o antipalos
		}else if(player == BotParser.mServerId){
			score = Integer.MAX_VALUE;

			for(Move m : moves){
				clone.simulateMove(m, BotParser.mServerId);	// Klwnopoihsh kathe kinhshs
				// Ypologismos tou score ths kathe kinhshs kalwntas anadromika ton minmax
				long currentScore = minmax(clone, depth - 1, alpha, beta, BotParser.mBotId);
				clone.undo(m, field);	// Anairesh ths kinhshs
				if(currentScore < score){
					// Enhmerwsh tou score
					score = currentScore;
					beta = score;

					// Xrhsh ab kladematos
					if(alpha >= beta){
						return score;
					}
				}
			}
		}

		return score;
	}

	/*
	public boolean isGameOver(Field field){
		return hasPlayerWon(PLAYER_X) || hasPlayerWon(PLAYER_O) || field.isFull()''
	}
	*/

	// H parakatw methodos elegxei an ena tetragwno einai adeio koitazontas tis diathesimes kinhseis
	public boolean isSubTableEmpty(ArrayList<Move> moves){
		if(moves.size() != 9){
			return false;
		}else{
			return ((moves.get(0).getX() + 2 == moves.get(8).getX()) && (moves.get(0).getY() + 2 == moves.get(8).getY()));
		}
	}

	// To vathos einai antistrofws analogo tou arithmou twn kinhsewn
	public static int getDepth(int movesSize, Field f){
		// Orizoume to vathos na einai 4 gia tis arxikes times 
		if(f.getMoveNumber() < 18 && movesSize > 7)
			return 4;

		int depth = 7;	// Arxikopoihsh tou depth

		if(movesSize < 5){
			depth = 9;
		}else if(movesSize == 5){
			depth = 8;
		}

		if(movesSize > 7 && movesSize <= 10){
			depth = 5;
		}else if(movesSize > 10 && movesSize <= 17){
			depth = 4;
		}else if(movesSize > 17 && movesSize <= 46){
			depth = 3;
		}else if(movesSize > 46){
			depth = 2;
		}


		if(BotParser.mtimeRemaining < 4000 && depth > 3){
			depth = 3;
		}else if(BotParser.mtimeRemaining < 2000){
			depth = 1;
		}

		return depth; 
	}


	public static void main(String[] args) {
		BotParser parser = new BotParser(new BotStarter());
		parser.run();
	}
}
